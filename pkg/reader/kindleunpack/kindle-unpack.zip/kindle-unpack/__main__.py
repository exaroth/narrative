#!/usr/bin/env python3

import getopt
import os
import sys
import traceback

from compatibility_utils import unicode_argv
from kindleunpack import unpackBook

def run(argv=unicode_argv()):

    try:
        _, args = getopt.getopt(argv[1:], "")
    except getopt.GetoptError as err:
        print(str(err))
        sys.exit(2)

    apnxfile = None
    epubver = '2'
    use_hd = False

    if len(args) < 2:
        print("Not enough args passed, must pass at least source and target dir")
        return 1
    else:
        infile, outdir = args

    infileext = os.path.splitext(infile)[1].upper()
    if infileext not in ['.MOBI', '.PRC', '.AZW', '.AZW3', '.AZW4']:
        print("Error: first parameter must be a Kindle/Mobipocket ebook or a Kindle/Print Replica ebook.")
        return 1

    try:
        unpackBook(infile, outdir, apnxfile, epubver, use_hd)
    except ValueError as e:
        print("Error: %s" % e)
        print(traceback.format_exc())
        return 1
    return 0

sys.exit(run())
